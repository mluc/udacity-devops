# udacity-devops-proiject3

## Github:
https://github.com/mluc/static

## Jenkins:
http://ec2-18-212-12-246.compute-1.amazonaws.com:8080/

## Static website:
http://jenkins-project2.s3-website-us-east-1.amazonaws.com/
